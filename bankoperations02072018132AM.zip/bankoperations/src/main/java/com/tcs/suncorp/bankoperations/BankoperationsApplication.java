package com.tcs.suncorp.bankoperations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankoperationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankoperationsApplication.class, args);
	}
}
