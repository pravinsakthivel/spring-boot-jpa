package com.tcs.suncorp.bankoperations.controller;

import com.tcs.suncorp.bankoperations.model.Account;
import com.tcs.suncorp.bankoperations.service.AccountService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;


@RestController
public class AccountController {

    Logger log = LoggerFactory.getLogger(AccountController.class);
    @Autowired
    AccountService accountService;

    //Test need to be removed
    @GetMapping("/")
    public ResponseEntity<List<Account>> welcomeclass(){

        List<Account> custlist = accountService.fetchCustomerDetails();
        return  new ResponseEntity<>(custlist,HttpStatus.OK);
    }

    //open a bank account
    @PostMapping("/accounts/")
    public ResponseEntity<Account> createBankAccount(@Valid @RequestBody Account account){
        log.info("In /account/createAccount  before invoking customerService.createAccount()");
        return accountService.createAccount(account);
    }

    //Edit account type
    @PatchMapping("/accounts/")
    public ResponseEntity<Account> updateAccountType(@RequestBody Account account){
        log.info("In /account/updateAccountType  before invoking customerService.updateAccountType() for Id :: "+ account.getId());
        return accountService.updateAccountType(account);
    }
}
