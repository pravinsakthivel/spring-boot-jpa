package com.tcs.suncorp.bankoperations.controller;


import com.tcs.suncorp.bankoperations.model.Transaction;
import com.tcs.suncorp.bankoperations.service.TransactionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
public class TransactionController {

    Logger log = LoggerFactory.getLogger(TransactionController.class);
    @Autowired
    private TransactionService transactionService;

    /*
        To view the list of transactions for give Id
        @returns list if transactions
    */
    @GetMapping("/accounts/{id}/transactions")
    public ResponseEntity<List<Transaction>> getAccountTransactions(@PathVariable(value="id") Long id){
        log.info("In Account Controller getAccountTransactions() ::");
        return transactionService.viewTransactions(id);

    }
    /*
    * Handle transactions either to deposit and withdraw
    * based on transaction type
    * */
    @PutMapping("/accounts/{id}/transactions")
    public ResponseEntity<String> handleTransactions(@PathVariable(value="id") Long id , @Valid @RequestBody Transaction transaction){
        log.info("In handle transactions controller ");
        return transactionService.handleTransactions(id,transaction);
    }

    /*
    * To transfer amount from one account to another account
    * @parms beneficiary id,transaction amount
    * */
    @PostMapping("/accounts/{id}/transactions")
    public ResponseEntity<String> fundTransfer(@PathVariable(value ="id") Long id,@RequestBody Transaction transaction){
        log.info("In fundTransfer controller ");
        return transactionService.transferAmount(id,transaction);
    }


}
