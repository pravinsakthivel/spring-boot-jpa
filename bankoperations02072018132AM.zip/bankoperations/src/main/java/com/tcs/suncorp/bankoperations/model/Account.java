package com.tcs.suncorp.bankoperations.model;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


@Entity
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private long id;

    @NotNull
    @Size(max = 20)
    @Column(name ="firstname")
    private String firstname;

    @NotNull
    @Size(max = 20)
    @Column(name ="lastname")
    private String lastname;

    @NotNull
    @Size(max = 20)
    @Column(name ="dob")
    private String dob;

    private String recoredcreateddt;

    private String recordUpdatedDt;

    @NotNull
    @Column(name="accounttype")
    private String accounttype;

    private double accountbalance;

    public Account(Long id, @NotNull @Size(max = 20) String firstname, @NotNull @Size(max = 20) String lastname, @NotNull @Size(max = 20) String dob, String recoredcreateddt, @NotNull String accounttype, double accountbalance, String recordUpdatedDt) {

        this.id = id;
        this.firstname = firstname;
        this.lastname = lastname;
        this.dob = dob;
        this.recoredcreateddt = recoredcreateddt;
        this.accounttype  = accounttype;
        this.accountbalance = accountbalance;
        this.recordUpdatedDt = recordUpdatedDt;
    }

    public Account(){
        super();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getRecoredcreateddt() {
        return recoredcreateddt;
    }

    public void setRecoredcreateddt(String recoredcreateddt) {
        this.recoredcreateddt = recoredcreateddt;
    }

    public String getAccounttype() {
        return accounttype;
    }

    public void setAccounttype(String accounttype) {
        this.accounttype = accounttype;
    }

    public double getAccountbalance() {
        return accountbalance;
    }

    public void setAccountbalance(double accountbalance) {
        this.accountbalance = accountbalance;
    }

    public String getRecordUpdatedDt() {
        return recordUpdatedDt;
    }

    public void setRecordUpdatedDt(String recordUpdatedDt) {
        this.recordUpdatedDt = recordUpdatedDt;
    }

}
