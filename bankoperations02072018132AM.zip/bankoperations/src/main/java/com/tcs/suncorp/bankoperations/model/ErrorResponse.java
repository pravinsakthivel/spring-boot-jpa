package com.tcs.suncorp.bankoperations.model;

import org.springframework.http.HttpStatus;

public class ErrorResponse {

    private HttpStatus errorCode;
    private String errorMessage;

    public ErrorResponse() {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public HttpStatus getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(HttpStatus errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
