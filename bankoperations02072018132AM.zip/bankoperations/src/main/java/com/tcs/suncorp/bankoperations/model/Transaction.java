package com.tcs.suncorp.bankoperations.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;

@Entity
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @NotNull
    @DecimalMin("0.01")
    private double transcationamount;

    private double closingbalance;

    private String transcationrefno;

    @NotNull
    private String transcationtype;

    private String recordcreateddt;
    @Transient
    private Long beneficiaryid;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "AccountId", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Account account;

    public Transaction(Long id , @NotNull double transcationamount, double closingbalance, Account account, String transcationrefno, String transcationtype, Long beneficiaryid, String recordcreateddt) {
        super();
        this.id = id;
        this.transcationamount = transcationamount;
        this.closingbalance = closingbalance;
        this.transcationrefno = transcationrefno;
        this.account = account;
        this.transcationtype = transcationtype;
        this.beneficiaryid = beneficiaryid;
        this.recordcreateddt = recordcreateddt;
    }

    public Transaction(){
        super();
    }

    public Transaction(double transcationamount) {
        this.transcationamount = transcationamount;
    }

    public Transaction(double transcationamount, Long beneficiaryid) {
        this.transcationamount = transcationamount;
        this.beneficiaryid = beneficiaryid;
    }

    public Transaction(double transcationamount, Long beneficiaryid, String transactiontype) {
        this.transcationamount = transcationamount;
        this.beneficiaryid = beneficiaryid;
        this.transcationtype = transactiontype;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public double getTranscationamount() {
        return transcationamount;
    }

    public void setTranscationamount(double transcationamount) {
        this.transcationamount = transcationamount;
    }

    public double getClosingbalance() {
        return closingbalance;
    }

    public void setClosingbalance(double closingbalance) {
        this.closingbalance = closingbalance;
    }

    public String getTranscationrefno() {
        return transcationrefno;
    }

    public void setTranscationrefno(String transcationrefno) {
        this.transcationrefno = transcationrefno;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public String getTranscationtype() {
        return transcationtype;
    }

    public void setTranscationtype(String transcationtype) {
        this.transcationtype = transcationtype;
    }

    public Long getBeneficiaryid() {
        return beneficiaryid;
    }

    public void setBeneficiaryid(Long beneficiaryid) {
        this.beneficiaryid = beneficiaryid;
    }

    public String getRecordcreateddt() {
        return recordcreateddt;
    }

    public void setRecordcreateddt(String recordcreateddt) {
        this.recordcreateddt = recordcreateddt;
    }
}
