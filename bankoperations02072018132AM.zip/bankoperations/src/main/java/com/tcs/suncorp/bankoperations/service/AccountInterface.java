package com.tcs.suncorp.bankoperations.service;

import com.tcs.suncorp.bankoperations.model.Account;
import org.springframework.http.ResponseEntity;

public interface AccountInterface {

    /*
        To create a bank account for customer
    */
    ResponseEntity<Account> createAccount(Account account);

    /*
        To Edit the type of Account
    * */
    ResponseEntity<Account> updateAccountType(Account account);

}
