package com.tcs.suncorp.bankoperations.service;

import com.tcs.suncorp.bankoperations.exceptionhandler.ResourceNotFoundException;
import com.tcs.suncorp.bankoperations.model.Account;
import com.tcs.suncorp.bankoperations.respository.AccountRepository;
import com.tcs.suncorp.bankoperations.utilities.OperationsManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountService  implements AccountInterface {
    Logger log = LoggerFactory.getLogger("AccountService.class");

    @Autowired
    AccountRepository accountRepository;

    //open a bank account service
    public ResponseEntity<Account> createAccount(Account account) {
        OperationsManager operationsManager = new OperationsManager();
        operationsManager.validateAccountDetails(account);
        account.setAccountbalance(0.00);
        account.setRecoredcreateddt(operationsManager.sysdate());
        accountRepository.save(account);
        return  new ResponseEntity<>(account,HttpStatus.OK);
    }

    /*
    * Service to update the account type either as savings or deposit
    * */
    public ResponseEntity<Account> updateAccountType(Account account) {
        OperationsManager operationsManager = new OperationsManager();
        operationsManager.validateAccountType(account.getAccounttype());
        account.setRecordUpdatedDt(operationsManager.sysdate());
        log.info("In service updateAccountType");
        accountRepository.findById(account.getId()).map(fetchedRecord -> {
                    fetchedRecord.setAccounttype(account.getAccounttype().toUpperCase());
                    return accountRepository.save(fetchedRecord);
                }
        ).orElseThrow(() ->new ResourceNotFoundException("No Records found for Id "+ account.getId()));
        return new ResponseEntity<>(account,HttpStatus.OK);
    }


    //Test need to be removed
    public List<Account> fetchCustomerDetails() {
        return accountRepository.findAll();
    }

    /*
    * Service to fetch a customer record by a Id
    * */
    public Account findById(Long id) {

        return accountRepository.findById(id).orElseThrow(()->new ResourceNotFoundException("No Records found for Id ::" + id));
    }

}
