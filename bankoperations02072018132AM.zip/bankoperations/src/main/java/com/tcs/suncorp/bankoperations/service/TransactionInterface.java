package com.tcs.suncorp.bankoperations.service;

import com.tcs.suncorp.bankoperations.model.Transaction;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface TransactionInterface {
    /*
    * To view the list of transactions
    * */
    ResponseEntity<List<Transaction>> viewTransactions(Long id);

    /*
    To handle deposit/withdraw transactions
    * */
    ResponseEntity<String> handleTransactions(Long id, Transaction transaction);

    /*
    * To transfer a  amount*/
    ResponseEntity<String> transferAmount(Long id, Transaction transaction);
}
