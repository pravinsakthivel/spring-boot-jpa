 package com.tcs.suncorp.bankoperations.service;

import com.tcs.suncorp.bankoperations.exceptionhandler.InvalidRequestException;
import com.tcs.suncorp.bankoperations.model.Account;
import com.tcs.suncorp.bankoperations.model.Transaction;
import com.tcs.suncorp.bankoperations.respository.TransactionRepository;
import com.tcs.suncorp.bankoperations.utilities.OperationsManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


 @Service
public class TransactionService implements TransactionInterface {

    Logger log = LoggerFactory.getLogger(TransactionService.class);

     @Value("${app.deposit.url}")
     private String depositUrl;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private AccountService accountService;

/*
    View Transcations for the given Id
    @Returns List of Transactions for given Id
*/
    public ResponseEntity<List<Transaction>> viewTransactions(Long id) {
        log.info("In AccountService viewTransactions() fetching details for Id "+id);
        List<Transaction> transactionList = transactionRepository.findByAccountId(id);
        if(transactionList.size() > 0){
            return  new ResponseEntity<>(transactionList,HttpStatus.OK);
        }else{
            throw new InvalidRequestException("No Transactions found for id "+id+" or invalid account id");
        }
    }

        public synchronized ResponseEntity<String> handleTransactions(Long id,Transaction transaction){
        log.info("Id is handleTransactions :"+id);
        if("CREDIT".equalsIgnoreCase(transaction.getTranscationtype())){
            depositAmount(id,transaction);
        }
        if("DEBIT".equalsIgnoreCase(transaction.getTranscationtype())){
            withdrawAmount(id,transaction);
        }
        return new ResponseEntity<>("Transaction success new balance is :"+transaction.getClosingbalance(),HttpStatus.OK);
    }
    /*
        Service to deposit
        @parms Id,Account Entity
        @returns Success
    */
    private ResponseEntity<String> depositAmount(Long id, Transaction transaction) {

            log.info("Deposit amount for Id "+id);
                Account customerdetails = accountService.findById(id);
                log.info("Existing balance in account is" + customerdetails.getAccountbalance() +"transaction amount :"+transaction.getTranscationamount());
                OperationsManager util = new OperationsManager();
                double updatedBalance = util.creditBalance(customerdetails, transaction);
                log.info("updated balance is ::"+updatedBalance);
                customerdetails.setAccountbalance(updatedBalance);
                transaction.setClosingbalance(updatedBalance);
                transaction.setTranscationtype("CREDIT");
                transaction.setAccount(customerdetails);
                transaction.setTranscationrefno(util.getTransactionId());
                transaction.setRecordcreateddt(util.sysdate());
                transactionRepository.save(transaction);

        return new ResponseEntity<>("Transaction success new balance is "+transaction.getClosingbalance(), HttpStatus.OK);
        }


    /*
    * Service to withdraw amount
    * @parms Id,Account Entity
    * @returns Success
    * */
    public ResponseEntity<String> withdrawAmount(Long id, Transaction transaction) {
        log.info("In AccountService withdrawAmount() method");
                Account customerdetails = accountService.findById(id);
                OperationsManager util = new OperationsManager();
                double deductedBalance = util.debitBalance(customerdetails, transaction);
                customerdetails.setAccountbalance(deductedBalance);
                transaction.setClosingbalance(deductedBalance);
                transaction.setTranscationtype("DEBIT");
                transaction.setAccount(customerdetails);
                transaction.setTranscationrefno(util.getTransactionId());
                transaction.setRecordcreateddt(util.sysdate());
                transactionRepository.save(transaction);

            return new ResponseEntity<>("Amount debited Successfully new balance is "+transaction.getClosingbalance(), HttpStatus.OK);

    }

    /*
    * Service to transfer fund between accounts
    * @parms Id,Account Entity,Beneficiary Id
    * */
    public ResponseEntity<String> transferAmount(Long id, Transaction transaction) {
        log.info("In AccountService transferAmount() method");

            if(id != transaction.getBeneficiaryid()){
                transaction.setTranscationtype("DEBIT");
                log.info("Amount to be transferred is ::"+transaction.getTranscationamount());
                handleTransactions(id,transaction);
                invokeCreditService(transaction,transaction.getBeneficiaryid());
                return new ResponseEntity<>("Amount Transferred successfully ",HttpStatus.OK);
            }else{
                throw new InvalidRequestException("Payer Id and Beneficiary Id cannot be same");
            }

    }

    /*
    * Rest call to invoke deposit service
    * */
    private boolean invokeCreditService(Transaction transaction,Long id) {
        log.info("In invokeCreditService() method for id"+id);

        Account customerdetails = accountService.findById(id);
        if(customerdetails.getId() == transaction.getBeneficiaryid()){
            OperationsManager util = new OperationsManager();
            Map<String, String> request = new HashMap<>();
            request.put("id",String.valueOf(id));
            RestTemplate restTemplate = new RestTemplate();
            String url = depositUrl ;
            log.info("Benefiiary amount "+transaction.getBeneficiaryid());
            log.info("To be transferred is ::"+transaction.getTranscationamount());
            transaction.setTranscationtype("CREDIT");
            Transaction transact = new Transaction(transaction.getTranscationamount(),transaction.getBeneficiaryid(),transaction.getTranscationtype());
            restTemplate.put( url, transact,request);
        }
        return true;
    }


    public List<Transaction> fetchAccountetails() {
        return transactionRepository.findAll();
    }
}
