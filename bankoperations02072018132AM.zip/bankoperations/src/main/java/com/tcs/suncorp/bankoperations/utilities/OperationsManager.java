package com.tcs.suncorp.bankoperations.utilities;

import com.tcs.suncorp.bankoperations.exceptionhandler.InvalidRequestException;
import com.tcs.suncorp.bankoperations.model.Account;
import com.tcs.suncorp.bankoperations.model.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;


public class OperationsManager {

    Logger log = LoggerFactory.getLogger(OperationsManager.class);
/*
    validate method for createbankaccount functionality
*/
    public void validateAccountDetails(Account account){
        isDateValid(account.getDob());
        validateAccountType(account.getAccounttype());
        isAlphabetic(account.getFirstname(),"firstname");
        isAlphabetic(account.getLastname(),"lastname");
    }

/*
    validate accounttype either SAVINGS or DEPOSIT
*/
    public boolean validateAccountType(String accounttype) {

        if(("SAVINGS").equalsIgnoreCase(accounttype) || ("DEPOSIT").equalsIgnoreCase(accounttype)){
            return true;
        }else{
            //handle exceptions
            throw new InvalidRequestException("Not a valid Account Type");
        }
    }

/*
    validate whether input string contains only alphabets
*/
    public  boolean isAlphabetic(String input,String filedName) {
        for (int i = 0; i != input.length(); ++i) {
            if (!Character.isLetter(input.charAt(i))) {
                throw new InvalidRequestException(filedName +" is not in required format,should contain only alphabets");
            }
        }

        return true;
    }

/*
    validate date in dd-MM-YYYY format
*/
    private boolean isDateValid(String dateToValidate) {
        log.info("isDateValid function :: dateToValidate is"+dateToValidate);
        boolean vaildFlag = false;
        if(dateToValidate == null){
            return false;
        }


        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-YYYY");
        sdf.setLenient(false);

        try {
            //if not valid, it will throw ParseException
            Date dateField = sdf.parse(dateToValidate);
            log.info("Parsed date is :: "+dateField);
           return true;
        } catch (ParseException e) {
            //handle exceptions
            throw new InvalidRequestException("Date is not in a valid format");
        }
            }

    /*Method to get system date*/
    public String sysdate(){

        String pattern = "dd-MM-YYYY";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        String date = simpleDateFormat.format(new Date());
        return date;

    }

    public double creditBalance(Account customerdetails, Transaction transaction) {
        double updatedBalance = customerdetails.getAccountbalance() + transaction.getTranscationamount();
        return updatedBalance;

    }

    public double debitBalance(Account customerdetails, Transaction transaction) {
        if(customerdetails.getAccountbalance() >= transaction.getTranscationamount() ) {
            double deductedBalance =customerdetails.getAccountbalance() - transaction.getTranscationamount();
            return deductedBalance;
        }else{
            throw  new InvalidRequestException("Insufficient fund in account");
        }
    }

    public String getTransactionId() {

        String uniqueKey = UUID.randomUUID().toString();
        return uniqueKey;

    }

}
