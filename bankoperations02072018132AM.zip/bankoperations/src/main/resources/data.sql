
insert into Account values(100,5000.00,'Savings','2018-06-12','Ram','Pravin',sysdate,sysdate);
insert into Account values(101,5000.00,'Savings','2018-06-12','Test','Account',sysdate,sysdate);

insert into Transaction values(1,5000.00,5000.00,'123154',sysdate,'CREDIT',100);

