package com.tcs.suncorp.bankoperations.controller;

import com.tcs.suncorp.bankoperations.model.Account;
import com.tcs.suncorp.bankoperations.service.AccountService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.DefaultMockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
@WebMvcTest(AccountController.class)
public class AccountControllerTest {

    @Autowired
    MockMvc mockMvc;

    @Autowired
    private WebApplicationContext wac;

    @MockBean
    private AccountService accountService;

    Account mockAccount = new Account((long) 100,"Ram","Pravin","16-06-1993",
            "26-06-2018","Savings",5000.00,"26-06-1993");
    String inputJSON = "{\"id\":10,\"firstname\":\"test\",\"lastname\":\"demo\",\"dob\":\"16-06-1993\",\"accounttype\":\"SAVINGS\"}";

    @Before
    public void setup () {
        DefaultMockMvcBuilder builder = MockMvcBuilders.webAppContextSetup(this.wac);
        this.mockMvc = builder.build();
    }

    @Test
    public void createBankAccount() throws Exception {

        ResponseEntity<Account> mockcustomerRes = new ResponseEntity<>(mockAccount,HttpStatus.OK);
        Mockito.when(accountService.createAccount(any(Account.class))).thenReturn(mockcustomerRes);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post(
                "/accounts/").accept(
                MediaType.APPLICATION_JSON).content(inputJSON).contentType(MediaType.APPLICATION_JSON);


        MvcResult result = mockMvc.perform(requestBuilder).andReturn();

        MockHttpServletResponse response = result.getResponse();

        assertEquals(HttpStatus.OK.value(), response.getStatus());
        System.out.println("response"+ result.getResponse().getStatus());

    }


    @Test
    public void updateAccountTpye() throws Exception {


        ResponseEntity<Account> mockcustomerRes = new ResponseEntity<>(mockAccount,HttpStatus.OK);
        Mockito.when(accountService.updateAccountType(any(Account.class))).thenReturn(mockcustomerRes);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.patch(
                "/accounts/").contentType(MediaType.APPLICATION_JSON).content(inputJSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();

        MockHttpServletResponse response = result.getResponse();

        assertEquals(HttpStatus.OK.value(), response.getStatus());

    }


}
