package com.tcs.suncorp.bankoperations.controller;

import com.tcs.suncorp.bankoperations.model.Account;
import com.tcs.suncorp.bankoperations.model.Transaction;
import com.tcs.suncorp.bankoperations.service.AccountService;
import com.tcs.suncorp.bankoperations.service.TransactionService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.DefaultMockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;

@RunWith(SpringRunner.class)
@WebMvcTest(TransactionController.class)
public class TransactionControllerTest {

    @Autowired
    MockMvc mockMvc;

    @Autowired
    private WebApplicationContext wac;

    @MockBean
    private TransactionService transactionService;

    @MockBean
    private AccountService accountService;

    String inputJson = "{\"transcationamount\":200,\"transcationtype\":\"DEBIT\"}";

    @Before
    public void setup () {
        DefaultMockMvcBuilder builder = MockMvcBuilders.webAppContextSetup(this.wac);
        this.mockMvc = builder.build();
    }


    Account mockAccount = new Account((long) 100,"Ram","Pravin","16-06-1993",
            "26-06-2018","Savings",5000.00,"26-06-1993");

    @Test
    public void depoistAmount() throws Exception {

        ResponseEntity<String> mockcustomerRes = new ResponseEntity<>("Amount deposited successfully to account",HttpStatus.OK);
        Mockito.when(transactionService.handleTransactions(anyLong(),any(Transaction.class))).thenReturn(mockcustomerRes);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.put(
                "/accounts/100/transactions/").accept(
                MediaType.APPLICATION_JSON).content(inputJson).contentType(MediaType.APPLICATION_JSON);


        MvcResult result = mockMvc.perform(requestBuilder).andReturn();

        MockHttpServletResponse response = result.getResponse();

        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }


    @Test
    public void withdrawAmount() throws Exception {

        ResponseEntity<String> mockcustomerRes = new ResponseEntity<String>("Amount debited successfully",HttpStatus.OK);
        Mockito.when(transactionService.handleTransactions(anyLong(),any(Transaction.class))).thenReturn(mockcustomerRes);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.put(
                "/accounts/100/transactions/").accept(
                MediaType.APPLICATION_JSON).content(inputJson).contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();

        MockHttpServletResponse response = result.getResponse();

        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void transfermount() throws Exception{

        ResponseEntity<String> mockResponse = new ResponseEntity<>("Transaction success",HttpStatus.OK);
        Mockito.when(transactionService.transferAmount(anyLong(),any(Transaction.class))).thenReturn(mockResponse);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post(
                "/accounts/100/transactions").accept(
                MediaType.APPLICATION_JSON).content(inputJson).contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();

        MockHttpServletResponse response = result.getResponse();

        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void getAccountTransactions() throws Exception {

        ResponseEntity<List<Transaction>> transactionList = transactionService.viewTransactions((long) 100);
        Mockito.when(transactionService.viewTransactions(anyLong())).thenReturn(transactionList);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/accounts/100/transactions/").accept(
                MediaType.APPLICATION_JSON);


        MvcResult result = mockMvc.perform(requestBuilder).andReturn();

        MockHttpServletResponse response = result.getResponse();

        assertEquals(HttpStatus.OK.value(), response.getStatus());

    }
}
